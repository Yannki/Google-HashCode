import java.util.ArrayList;

public class Pizza {
    public String[] ingredients;

    public Pizza(String[] ingredients){
        this.ingredients = ingredients;
    }

}

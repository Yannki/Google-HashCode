import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Parser {
    public static final String prefixIn = "src/InputFiles/";
    public static final String prefixOut = "src/OutFiles/";
    public static ArrayList<Pizza> data = new ArrayList<>();
    //variables
    public static int pizzaTotal;
    public static int twoPeople;
    public static int threePeople;
    public static int fourPeople;

    public static void ReadFile(String name) throws FileNotFoundException {
        Scanner in = new Scanner(new File(prefixIn + name));

        String line;

        pizzaTotal = in.nextInt();
        twoPeople = in.nextInt();
        threePeople = in.nextInt();
        fourPeople = in.nextInt();

        in.nextLine();

        while (in.hasNextLine()) {
            in.next();
            line = in.nextLine();
            System.out.println(line);
            data.add(new Pizza(line.split(" ")));
        }

        in.close();
    }

    public static void WriteFile(ArrayList<String> input, String outputFile) throws IOException {
        BufferedWriter out = new BufferedWriter(new FileWriter(prefixOut + outputFile));
        out.write(input.size() + "\n");
        for (String t: input) {
            out.write(t + "\n");
        }

        out.close();
    }
}

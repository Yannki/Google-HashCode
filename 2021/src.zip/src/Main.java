import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;


public class Main {
    public static void main(String[] args) throws IOException {
        Parser.ReadFile("pizza.txt");

        ArrayList<String> result = new ArrayList<>();
        Random rand = new Random();
        int team;
        String line;
        for (int i = 2; i <= 4; i++){
            result.add(Integer.toString(i));
        }

        for (int i = 0; i < Parser.pizzaTotal; i++){
            team = rand.nextInt(3);

            line = result.get(team);
            result.set(team,line + " " + i);
        }

        Parser.WriteFile(result,"pizzaTest.txt");
    }
}
